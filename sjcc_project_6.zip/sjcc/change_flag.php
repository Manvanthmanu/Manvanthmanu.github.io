<?php
if(t==1)
$flag=0;
else 
$flag=0;
echo $flag;
?>